//corregir 
#include <iostream>
using namespace std;

class Calculadora {
public:
    float suma (float n1, float n2){
    return n1 + n2;
    }
    float resta (float n1, float n2){
    return n1 - n2;
    }
    float multiplicacion (float n1, float n2){
    return n1 * n2;
    }
    float division (float n1, float n2){
    return n1 / n2;
    }
};

int main(){
    float n1, n2;
    int op;
 cout << "Inserta la operacion que quieres realizar (1.- Suma, 2.-Resta, 3.-Multiplicacion, 4.-Division: ";
 cin >> op;
 cout << "Inserta el primer numero a operar: ";
 cin >> n1;
 cout << "Inserta el segundo numero a operar: ";
 cin >> n2;

 Calculadora calc;
 switch (op){
case 1:
    cout << "La suma es: " << calc.suma(n1, n2) << endl;
    break;
case 2:
    cout << "La resta es: " << calc.resta(n1, n2) << endl;
    break;
case 3:
    cout << "La multiplicacion es: " << calc.multiplicacion(n1, n2) << endl;
    break;
case 4:
    cout << "La division es: " << calc.division(n1, n2) << endl;
    break;

default:
    cout << "Entrada invalida, ingresa 1, 2, 3 o 4" << endl;
    }

    return 0;
}
