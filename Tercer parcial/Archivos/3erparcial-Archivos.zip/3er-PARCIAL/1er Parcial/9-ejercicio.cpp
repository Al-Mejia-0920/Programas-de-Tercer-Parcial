#include <iostream>
using namespace std;

int main() {
    float numeros[5];
    float suma = 0, media, maximo, minimo;

    
    for(int i = 0; i <= 4; i++) {
        printf("Ingrese un numero:  ");
        scanf("%f",&numeros[i]);
        suma= suma + numeros[i];

        if (numeros[i]>maximo){

           maximo = numeros[i];

        }else{

            if (numeros[i]< minimo);{
            minimo = numeros[i];
            }
        } 

    } media = suma/5;
    printf("Tu resultado de la suma es:%f \n",suma);
    printf("Tu resultado mayor es: %f \n",maximo);
    printf("Tu resultado minimo es: %f \n",minimo);
    printf("Tu media de los 5 numero son: %f \n",media);

    return 0;
}