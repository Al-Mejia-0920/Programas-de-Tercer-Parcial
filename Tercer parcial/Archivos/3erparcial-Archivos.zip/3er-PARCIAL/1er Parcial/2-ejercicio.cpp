//Ejercicio 2 generar objetos

#include <iostream>

using namespace std;

void Suma(int,int,int&);

int main()
{
    int Num1,Num2,Operacion;

    cout<<"Ingrese un digito :";
    cin>>Num1;
     cout<<"Ingrese un digito :";
    cin>>Num2;

    Suma(Num1,Num2,Operacion);

    cout<<"El resultado de la suma es :"<<Operacion<<endl;

    return 0;
}

void Suma(int Num1,int Num2 ,int& Operacion)
{
   Operacion=Num1+Num2;
};
