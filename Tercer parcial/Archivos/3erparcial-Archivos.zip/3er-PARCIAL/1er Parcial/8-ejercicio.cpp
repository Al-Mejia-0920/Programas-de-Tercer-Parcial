#include <iostream>
#include <algorithm>

using namespace std;

class Estadistica{
public:
    float promedio (float n[], int j){
        float res = 0;
        for(int i= 0; i<j; i++){
            res += n[i];
        }
        return res / j;
    }
    float media (float n[], int j){
        sort (n, n+j);
        if (j%2 !=0){
            return n[j/2];
        } else {
        return (n[j/2 -1] + n[j/2])/2;
        }
    }
    float maximo (float n[], int j){
    float max = n[0];
        for (int i = 0; i<j; i++){
            if (max < n[i]){
                max= n[i];
            }
        }
    return max;
    }
    float minimo (float n[], int j){
    float min = n[0];
        for (int i = 0; i<j; i++){
            if (min > n[i]){
                min= n[i];
            }
        }
    return min;
    }
    float suma (float n[], int j){
    float res= 0;
    for (int i=0; i<j; i++){
        res += n[i];
        }
        return res;
    }
};

int main (){
    Estadistica calc;
    float n[5];
    int j= 0;
cout << "Ingresa 5 numeros: " << endl;
    for (j=0; j<5; j++){
        cin >> n[j];
    }
    cout << "Tu promedio es: " << calc.promedio(n, j) << endl;
    cout << "Tu media es: " << calc.media(n, j) << endl;
    cout << "Tu maximo es: " << calc.maximo(n, j) << endl;
    cout << "Tu minimo es: " << calc.minimo(n, j) << endl;
    cout << "Tu suma es: " << calc.suma(n, j) << endl;
return 0;
}
