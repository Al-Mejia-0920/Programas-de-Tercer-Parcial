#include <iostream>
#include <string>
#include "abstracta.h"

using namespace std;

PCon::PCon(int total) {
    max_tam = total;
    pila = new string[max_tam];
    tope = -1;
}

PCon::~PCon() {
    delete[] pila;
}

void PCon::push(string elemento) {
    if (tope < max_tam - 1) {
        tope++;
        pila[tope] = elemento;
        cout << "Palabra \"" << elemento << "\" agregada.\n";
    } else {
        cout << " La pila llego a su limite.\n";
    }
}

string PCon::pop() {
    if (!estaVacia()) {
        string elementoEliminado = pila[tope];
        tope--;
        cout << "La palabra \"" << elementoEliminado << "\" eliminada.\n";
        return elementoEliminado;
    } else {
        cout << " La pila esta vacia.\n";
        return "";
    }
}

bool PCon::estaVacia() {
    return tope == -1;
}

bool PCon::estaLlena() {
    return tope == max_tam - 1;
}

void PCon::mostrarPila() {
    if (estaVacia()) {
        cout << " La pila esta vacia.\n";
    } else {
        cout << "Estado de la pila:\n";
        for (int i = tope; i >= 0; i--) {
            cout << "Lugar " << i << " -> " << pila[i] << "\n";
        }
    }
}

int PCon::obtTam() {
    return tope + 1;
}
