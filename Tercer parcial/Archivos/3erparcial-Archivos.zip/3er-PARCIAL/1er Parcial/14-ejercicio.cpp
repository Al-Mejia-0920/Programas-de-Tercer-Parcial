#include <iostream>
using namespace std;

class Recursividad {
    public:
    int multi (int a, int b){
        if (b==0){
            return 0;
        }
        if (b<0){
            return -multi (a, -b);
        }
        return a + multi(a, b-1);
    }
    int potencia (int a, int b){
    if (b==0){
        return 1;
    }
    return multi(a, potencia(a, b-1));
    }
    int fibonacci(int n) {
        if (n <= 1) {
            return n;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
}

    int factorial (int n){
    if (n <= 1){
    return 1;
    }
    return n * factorial(n - 1);
    }

};

int main() {
    Recursividad rec;
    int n, a, b;

    cout << "Calcular factorial de: "; cin >> n;
    cout << "Resultado: " << rec.factorial(n) << endl;

    cout << "Fibonacci: "; cin >> n;
    cout << "El termino " << n << " es: " << rec.fibonacci(n) << endl;

    cout << "Multiplicacion: " << endl;
    cout << "a: "; cin >> a;
    cout << "b: "; cin >> b;
    cout << "Resultado: " << rec.multi(a, b) << endl;

    cout << "Potencia: " << endl;
    cout << "a: "; cin >> a;
    cout << "b: "; cin >> b;
    cout << "Resultado: " << rec.potencia(a, b) << endl;

    return 0;
}
