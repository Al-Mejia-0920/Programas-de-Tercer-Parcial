#include <iostream>
using namespace std;

class Calculadora {
public:
    float suma (float n1, float n2){
    return n1 + n2;
    }
    float resta (float n1, float n2){
    return n1 - n2;
    }
    virtual float multiplicacion (float n1, float n2){
    return n1 * n2;
    }
    virtual float division (float n1, float n2){
    return n1 / n2;
    }
};

class Calculadora2: public Calculadora {
public:
    float multiplicacion (float n1, float n2) override{
        float res = 0;
    for(int i= 0; i<n2; i++){
        res += n1;
    }
    return res;
    }
    float division (float n1, float n2) override{
        float res = 0;
        if (n2==0){
            return 0;
        }
    while (n1>=n2){
        n1= n1-n2;
        res++;
    }
        return res;
    }
    float potencia (float n1, float n2){
    float res = 1;
    for(int i=0; i<n2; i++){
        res = res * n1;
    }
    return res;
    }


};

int main(){
    float n1, n2;
    int op;
 cout << "Inserta la operacion que quieres realizar (1.- Suma, 2.-Resta, 3.-Multiplicacion, 4.-Division:, 5.-Potencia): ";
 cin >> op;
 cout << "Inserta el primer numero a operar: ";
 cin >> n1;
 cout << "Inserta el segundo numero a operar: ";
 cin >> n2;

 Calculadora2 calc;

 switch (op){
case 1:
    cout << "La suma es: " << calc.suma(n1, n2) << endl;
    break;
case 2:
    cout << "La resta es: " << calc.resta(n1, n2) << endl;
    break;
case 3:
    cout << "La multiplicacion es: " << calc.multiplicacion(n1, n2) << endl;
    break;
case 4:
    cout << "La division es: " << calc.division(n1, n2) << endl;
    break;
case 5:
    cout << "La potencia es: " << calc.potencia(n1, n2) << endl;
    break;
default:
    cout << "Entrada invalida, ingresa 1, 2, 3, 4 o 5" << endl;
    }
    return 0;
}


