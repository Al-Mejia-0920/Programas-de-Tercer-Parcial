#ifndef CONVERTIDOR_H
#define CONVERTIDOR_H
#include <string>
#include <fstream>

using namespace std;

class IConvertidor {
public:
    virtual ~IConvertidor() {}
    virtual string generartexto() = 0;
    virtual void guardar(string nombrearchivo) = 0;
};

class Convertidor : public IConvertidor {
protected:
    string contenido;
    string datos;
public:
    Convertidor(string cont, string dat) : contenido(cont), datos(dat) {}
    virtual string generartexto() = 0;
    void guardar(string nombrearchivo) override {
        ofstream archivo(nombrearchivo);
        archivo << generartexto();
        archivo.close();
    }
};

class ConvertidorTXT : public Convertidor {
public:
    ConvertidorTXT(string cont, string dat) : Convertidor(cont, dat) {}
    string generartexto() override;
};

class ConvertidorJSON : public Convertidor {
public:
    ConvertidorJSON(string cont, string dat) : Convertidor(cont, dat) {}
    string generartexto() override;
};

class ConvertidorXML : public Convertidor {
public:
    ConvertidorXML(string cont, string dat) : Convertidor(cont, dat) {}
    string generartexto() override;
};

class ConvertidorCSV : public Convertidor {
public:
    ConvertidorCSV(string cont, string dat) : Convertidor(cont, dat) {}
    string generartexto() override;
};

#endif
