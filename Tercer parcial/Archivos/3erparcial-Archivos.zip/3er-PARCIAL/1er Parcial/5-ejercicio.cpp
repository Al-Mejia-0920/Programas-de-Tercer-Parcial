#include<iostream>
using namespace std;

class calculadora
{
private:
public:
     float a,b;
   void pedir();
};

void calculadora ::pedir()
{
    cout<<"\nIngrese el primer digito : ";cin>>a;
    cout<<"\nIngrese su segundo digito : ";cin>>b;
}

class suma: public calculadora
{
   public:
       float operacion()
       {
           return a+b;
       }
};
class resta : public calculadora
{
public:
    float operacion()
    {
        return a-b;
    }
};
class multiplicacion : public calculadora
{
public:
    float operacion()
    {
        return a*b;
    }
};
class division : public calculadora
{
public:
    float operacion()
    {
        return a/b;
    }
};

int main()
{
    int opcion;

    cout<<"Ingrese la operacion que deseas hacer...\n1)Suma\n2)Resta\n3)Multiplicacion\n4)Division\n...";
    cin>>opcion;

    switch(opcion)
    {

    case 1 :
    {
    suma s;
    s.pedir();
    cout<<"Su resultado es : "<<s.operacion()<<endl;
    break;
    }

    case 2 :
    {
    resta r;
    r.pedir();
    cout<<"Su resultado es : "<<r.operacion()<<endl;
    break;
    }

    case 3 :
    {
    multiplicacion m;
    m.pedir();
    cout<<"Su resultado es : "<<m.operacion()<<endl;
    break;
    }

    case 4 :
    {
    division d;
    d.pedir();
    cout<<"Su resultado es : "<<d.operacion()<<endl;
    break;
    }

    case 5 :
    {
    cout<<"Saliendo...";
    break;
    default:
        cout<<"No valido";
    }
    }







    return 0;
}
