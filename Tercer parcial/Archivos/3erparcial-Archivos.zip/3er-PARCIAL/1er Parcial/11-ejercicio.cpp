#include <iostream>
using namespace std;
class Matriz{
public:
    void mxm(int a[][3], int b[][3]){
    int c[3][3] = {0};
    for (int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            for (int h=0; h<3; h++){
                c[i][j] += a[i][h] * b[h][j];
            }
        }
    }
    for (int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            cout << c[i][j] << " ";
        }
        cout << endl;
    }
    }
    void mxk(int a[][3]){
    int k;
    cout << "Inserta una constante para multiplicar ";
    cin >> k;
    for (int i=0; i<3; i++){
    for(int j=0; j<3; j++){
            a[i][j]=a[i][j]*k;
            }
        }
    for (int i=0; i<3; i++){
    for(int j=0; j<3; j++){
    cout << a[i][j] << " ";
    }
    cout << endl;
    }
    }
};

int main(){
int a[3][3];
int b[3][3];
int opc;
cout << "Inserta los valores de tu matriz A" << endl;
for (int i=0; i<3; i++){
    for(int j=0; j<3; j++){
            cin >> a[i][j];
    }
}
cout << "Inserta los valores de tu matriz B" << endl;
for (int i=0; i<3; i++){
    for(int j=0; j<3; j++){
            cin >> b[i][j];
    }
}

Matriz mat;
cout << "Escribe 1 si quieres multiplicar por la matriz y 2 si quieres multiplicar por una constante ";
cin >> opc;

switch (opc){
    case 1:
        mat.mxm(a, b);
        break;
    case 2:
        mat.mxk(a);
        break;
    default:
        cout << "Error, escoja 1 o 2"<< endl;
}

return 0;
}



