#include <string>

using namespace std;

class PCon {
private:
    string* pila;
    int tope;
    int max_tam;

public:
    PCon(int total);
    ~PCon();
    void push(string elemento);
    string pop();
    bool estaVacia();
    bool estaLlena();
    void mostrarPila();
    int obtTam();
};

