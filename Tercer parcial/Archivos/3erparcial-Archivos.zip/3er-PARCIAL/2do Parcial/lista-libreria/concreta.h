#include <iostream>
#include "abstracta.h"

using namespace std;

class lista : public dadlista {
public:
    lista() : dadlista() {}

    void agregar(string n, string e, string p) override {
        if (cantidad < 10) {
            arreglo[cantidad] = Persona(n, e, p);
            cantidad++;
            cout << "\nSe ha agregado a la lista\n";
        } else {
            cout << "\nLista llena...\n";
        }
    }

    void quitar() override {
        if (cantidad > 0) {
            cantidad--;
            Persona eliminado = arreglo[cantidad];
            cout << "\nSe ha eliminado... " << eliminado.nombre << "\n";
        } else {
            cout << "\nNo hay nadie para eliminar\n";
        }
    }

    void mostrar() override {
        for (int i = 0; i < cantidad; i++) {
            Persona p = arreglo[i];
            cout << "Nombre : " << p.nombre << "\n";
            cout << "Edad : " << p.edad << "\n";
            cout << "Peso : " << p.peso << "\n";
        }
    }

    bool vacia() {
        return cantidad == 0;
    }

    int tamano() {
        return cantidad;
    }

    bool llena() {
        return cantidad == 10;
    }
};
