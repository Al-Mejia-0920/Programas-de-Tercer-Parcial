#include <iostream>
#include <string>
#include "abstracta.h"

using namespace std;

int main() {
    int total;
    cout << "Cuantas palabras deseas que pueda almacenar la pila en total:";
    cin >> total;
    cin.ignore();
    PCon miPila(total);
    int opc;

    do {
        cout << "\n=== Menu de Pila Dinamica ===\n";
        cout << "1. Agregar elemento\n";
        cout << "2. Quitar elemento\n";
        cout << "3. Mostrar pila\n";
        cout << "4. Verificar estado (Vacia/Llena)\n";
        cout << "5. Mostrar tamano actual\n";
        cout << "6. Salir\n";
        cout << "Elige una opcion: ";
        cin >> opc;
        cin.ignore();

        switch (opc) {
            case 1: {
                cout << "Ingrese la palabra: ";
                string palabra;
                getline(cin, palabra);
                miPila.push(palabra);
                break;
            }
            case 2:
                miPila.pop();
                break;
            case 3:
                miPila.mostrarPila();
                break;
            case 4:
                cout << "Vacia: " << (miPila.estaVacia() ? "SI" : "NO") << "\n";
                cout << "Llena: " << (miPila.estaLlena() ? "SI" : "NO") << "\n";
                break;
            case 5:
                cout << "Elementos actuales: " << miPila.obtTam() << "\n";
                break;
            case 6:
                cout << "Saliendo...\n";
                break;
            default:
                cout << "Opcion no valida.\n";
                break;
        }
    } while (opc != 6);

    return 0;
}
