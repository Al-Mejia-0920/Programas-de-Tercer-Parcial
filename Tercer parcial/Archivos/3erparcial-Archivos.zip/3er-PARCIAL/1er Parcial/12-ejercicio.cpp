#include <iostream>
using namespace std;

struct coches {
    char modelo[20];
    float precio;
    int anio;
};

struct Persona {
    char nombre[20];
    char genero;
    int edad;
};
int main(){
    Persona listap[3];
    coches listac[3];

   for(int i = 0; i < 3; i++) {

    printf("Ingrese el nombre de la persona %d: ", i + 1);
    scanf("%s", listap[i].nombre);

    printf("Ingrese la edad de la persona %d: ", i + 1);
    scanf(" %d", &listap[i].edad);

    printf("Ingrese el genero de la persona %d: ", i + 1);
    scanf(" %c", &listap[i].genero);

    printf("Ingrese el modelo del coche %d: ", i + 1);
    scanf(" %s", listac[i].modelo);

    printf("Ingrese el precio del coche %d: ", i + 1);
    scanf(" %lf", &listac[i].precio);

    printf("Ingrese el ano del coche %d: ", i + 1);
    scanf(" %d", &listac[i].anio);
}
  return 0;
}
