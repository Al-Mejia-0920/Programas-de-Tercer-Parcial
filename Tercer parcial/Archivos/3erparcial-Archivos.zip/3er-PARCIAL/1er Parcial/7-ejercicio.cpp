#include <iostream>
#include <stdio.h>

using namespace std;

struct Auto {
    float precio; 
    int anio;     
};

struct Persona {
    char nombre[20]; 
    char ap[20];     
    char am[20];     
    char genero;     
    int edad;        
};

int main() {
    Auto miAuto;
    Persona miPersona;

    

    printf(" Tipos Basicos \n");
    printf("Tamano de char:  %ld byte\n", sizeof(char));
    printf("Tamano de int:   %ld bytes\n", sizeof(int));
    printf("Tamano de float: %ld bytes\n\n", sizeof(float));
    
    printf("Tamano de struct Auto: %ld bytes\n", sizeof(miAuto));
    
    printf("Tamano de struct Persona: %ld bytes\n", sizeof(miPersona));

    return 0;
}
