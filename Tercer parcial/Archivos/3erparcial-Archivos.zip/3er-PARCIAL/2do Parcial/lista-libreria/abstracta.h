#include <iostream>
#include <string>

using namespace std;

class Persona {
public:
    string nombre;
    string edad;
    string peso;

    Persona() {
        nombre = "";
        edad = "";
        peso = "";
    }

    Persona(string n, string e, string p) {
        nombre = n;
        edad = e;
        peso = p;
    }
};

class dadlista {
protected:
    Persona arreglo[10];
    int cantidad;

public:
    dadlista() {
        cantidad = 0;
    }
    virtual ~dadlista() {}

    virtual void agregar(string n, string e, string p) = 0;
    virtual void quitar() = 0;
    virtual void mostrar() = 0;
};
