#include "convertidor.h"
#include <sstream>

using namespace std;

string ConvertidorXML::generartexto() {
    string textofinal = "";
    textofinal += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    textofinal += "<programa>\n";
    textofinal += "  <archivo>resultado_ejecucion</archivo>\n";
    textofinal += "  <lenguaje>C++</lenguaje>\n";
    textofinal += "  <datos_ingresados>" + datos + "</datos_ingresados>\n";
    textofinal += "  <lineas_de_salida>\n";

    stringstream lector(contenido);
    string linea;
    int contador = 1;

    while(getline(lector, linea, '\n')) {
        textofinal += "    <linea_info>\n";
        textofinal += "      <id>" + to_string(contador) + "</id>\n";
        textofinal += "      <texto><![CDATA[" + linea + "]]></texto>\n";
        textofinal += "    </linea_info>\n";
        contador++;
    }

    textofinal += "  </lineas_de_salida>\n";
    textofinal += "</programa>\n";
    return textofinal;
}
