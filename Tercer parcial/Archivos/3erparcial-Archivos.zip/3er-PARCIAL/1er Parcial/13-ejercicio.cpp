#include <iostream>
using namespace std;

class coches
{
public :
    char modelo[20];
    float precio;
    int anio;
};

class Persona {
    public:
    char nombre[20];
    char genero;
    int edad;
};

class Lista
{
public :
  Persona listap[3];
  coches listac[3];

    Persona* p_ptr = listap;
    coches* c_ptr =listac;

    void Entrada();
    void Salida();
};


void Lista::Entrada()
{
    for (int i = 0; i < 3; i++) {
        printf("--- Registro %d ---\n", i + 1);


        printf("Nombre de la persona: ");
        scanf("%s", (p_ptr + i)->nombre);
        printf("Edad: ");
        scanf("%d", &(p_ptr + i)->edad);
        printf("Genero : ");
        scanf(" %c", &(p_ptr + i)->genero);


        printf("Modelo del coche: ");
        scanf("%s", (c_ptr + i)->modelo);
        printf("Precio: ");
        scanf("%f", &(c_ptr + i)->precio);
        printf("Anio: ");
        scanf("%d", &(c_ptr + i)->anio);
        printf("\n");
    }
}

void Lista::Salida()
{
    printf("---------- Lista ---------\n");
    for(int i=0;i<3;i++)
    {
          printf("Persona ....\n");
          printf("Nombre : %s \n",(p_ptr + i)->nombre);
          printf("Edad : %d \n",&(p_ptr + i)->edad);
          printf("Genero : %c \n",&(p_ptr + i)->genero);

          printf("Coche ....\n");
          printf("Modelo : %s \n",(c_ptr + i)->modelo);
          printf("Precio : $%.2f \n",&(c_ptr + i)->precio);
          printf("Anio : %d \n",&(c_ptr + i)->anio);
    printf("---------------------------\n");

    }
}

int main(){

    Lista L;
    L.Entrada();
    L.Salida();

  return 0;
}
