//Ejercicio 7Bis

#include<iostream>
using namespace std;

class TDatos {
public:
    int Entero;
    float Flotante;
    double PuntoFlotanteDoble;
    bool Booleano;
    char Caracter;
    short EnteroCorto;
    long EnteroLargo;

    TDatos ();
    ~TDatos ();
    void Mostrar();


};
    TDatos ::TDatos()
{
}
    TDatos ::~TDatos()
{
}

struct TDstruct
{
    int Entero;
    float Flotante;
    double PuntoFlotanteDoble;
    bool Booleano;
    char Caracter;
    short EnteroCorto;
    long EnteroLargo;
};


int main()
{
 TDatos Cantidad=TDatos();
 TDstruct PE;


 cout<<"------------   Clase  -----------\n";

 cout<<"\nEl valor del tipo de dato Entero es :"<<sizeof(Cantidad.Entero)<<endl<<endl;
  cout<<"El valor del tipo de dato Flotante es :"<<sizeof(Cantidad.Flotante)<<endl<<endl;
   cout<<"El valor del tipo de dato Double es :"<<sizeof(Cantidad.PuntoFlotanteDoble)<<endl<<endl;
    cout<<"El valor del tipo de dato Booleano es :"<<sizeof(Cantidad.Booleano)<<endl<<endl;
     cout<<"El valor del tipo de dato Caracter es :"<<sizeof(Cantidad.Caracter)<<endl<<endl;
      cout<<"El valor del tipo de dato Short es :"<<sizeof(Cantidad.EnteroCorto)<<endl<<endl;
       cout<<"El valor del tipo de dato Long es :"<<sizeof(Cantidad.EnteroLargo)<<endl<<endl;
       cout<<"El valor total de bytes de la clase es :"<<sizeof(TDatos)<<endl<<endl;
cout<<"________________________________\n";

cout<<"------------   Struct  -----------\n";

 cout<<"\nEl valor del tipo de dato Entero es :"<<sizeof(PE.Entero)<<endl<<endl;
  cout<<"El valor del tipo de dato Flotante es :"<<sizeof(PE.Flotante)<<endl<<endl;
   cout<<"El valor del tipo de dato Double es :"<<sizeof(PE.PuntoFlotanteDoble)<<endl<<endl;
    cout<<"El valor del tipo de dato Booleano es :"<<sizeof(PE.Booleano)<<endl<<endl;
     cout<<"El valor del tipo de dato Caracter es :"<<sizeof(PE.Caracter)<<endl<<endl;
      cout<<"El valor del tipo de dato Short es :"<<sizeof(PE.EnteroCorto)<<endl<<endl;
       cout<<"El valor del tipo de dato Long es :"<<sizeof(PE.EnteroLargo)<<endl<<endl;
       cout<<"El valor total de bytes de la clase es :"<<sizeof(TDstruct)<<endl<<endl;
cout<<"________________________________\n";


       return 0;

}
