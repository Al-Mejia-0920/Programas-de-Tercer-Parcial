#include "convertidor.h"
#include <sstream>

using namespace std;

string prepararparacsv(string linea) {
    string resultado = "";
    for (char letra : linea) {
        if (letra == '"') resultado += "\"\"";
        else if (letra != '\r') resultado += letra;
    }
    return resultado;
}

string ConvertidorCSV::generartexto() {
    string textofinal = "";
    textofinal += "archivo,lenguaje,datos_ingresados\n";
    textofinal += "resultado_ejecucion,C++,\"" + prepararparacsv(datos) + "\"\n\n";
    textofinal += "id,texto_salida\n";

    stringstream lector(contenido);
    string linea;
    int contador = 1;

    while(getline(lector, linea, '\n')) {
        textofinal += to_string(contador) + ",\"" + prepararparacsv(linea) + "\"\n";
        contador++;
    }

    return textofinal;
}
