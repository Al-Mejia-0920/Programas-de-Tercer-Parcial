#include "convertidor.h"

using namespace std;

string ConvertidorTXT::generartexto() {
    string textofinal = "";
    textofinal += "------------------------------------\n";
    textofinal += "             RESULTADO              \n";
    textofinal += "------------------------------------\n\n";
    textofinal += "--- Datos Ingresados ---\n";
    textofinal += datos + "\n\n";
    textofinal += "--- Salida ---\n";
    textofinal += contenido;
    return textofinal;
}
