#include <iostream>
using namespace std;

int sierpinski(int n) {

    if (n == 0) {
        return 1;
    }

    return 3 * sierpinski(n - 1);
}

int cantor(int n) {
    
    if (n == 0) {
        return 1;
    }
    return 4 * cantor(n - 1);
}

int main() {
    int nivel;

    printf("--- CALCULADORA DE FRACTALES RECURSIVOS ---\n");

    printf("Ingrese el nivel de detalle (n): ");
    
    scanf("%d", &nivel);

    if (nivel < 0) {
        printf("Por favor, ingrese un numero positivo.\n");
    } else {
        printf("\nResultados para el nivel %d:\n", nivel);
        printf("- Triangulos en Sierpinski: %d\n", sierpinski(nivel));
        printf("- Fragmentos en Polvo de Cantor: %d\n", cantor(nivel));
    }

    return 0;
}