#include <iostream>
using namespace std;


float sumar(float a, float b) {
    return a + b;
}
float sumar(float a, float b, float c) {
    return a + b + c;
}


float restar (float a, float b) {
    return a - b;
}
float restar(float a, float b, float c) {
    return a - b - c;
}

float multiplicar(float a, float b) {
    return a * b;
}
float multiplicar(float a, float b, float c) {
    return a * b * c;
}


float division (float a, float b) {
    return a / b;
}
float division(float a, float b, float c) {
    return a / b / c;
}

void calculadora( ){
    float x,y,z;
    char operador;

    printf("Calculadora \n");
    printf("Ingrese sus valores para la operacion junto con su simbolo \n");

    scanf("%f", &x);

    scanf(" %c",&operador);

    scanf("%f", &y);

    switch (operador) {
    case '+':
        z = x + y;
        printf("=%f",z);
        break;

    case '-':
        z = x - y;
        printf("=%f",z);
        break;

    case '*':
        z= x * y;
        printf("=%f",z);
     break;

    case '/':
        z= x / y;
        printf("=%f",z);
        break;

    default:
        printf("Operador no válido");

    }
}

int main() {
    cout << "Suma con 2 parametros:10 + 5 = " << sumar(10, 5) << endl;
    cout << "Suma con 3 parametros:10 + 5 + 2 = " << sumar(10, 5, 2) << endl;

    cout << "Suma con 2 parametros:10 - 5 =" << restar(10, 5) << endl;
    cout << "Suma con 3 parametros:10 - 5 - 2 = " << restar(10, 5, 2) << endl;

    cout << "Suma con 2 parametros:10 * 5 = " << multiplicar(10, 5) << endl;
    cout << "Suma con 3 parametros:10 * 5 * 2 = " << multiplicar(10, 5, 2) << endl;

    cout << "Suma con 2 parametros:10 / 5 = " << division(10, 5) << endl;
    cout << "Suma con 3 parametros:10 / 5 / 2 = " << division(10, 5, 2) << endl;

    calculadora();
    return 0;
}
