#include "convertidor.h"
#include <sstream>

using namespace std;

string prepararparajson(string texto) {
    string resultado = "";
    for (char letra : texto) {
        if (letra == '"') resultado += "\\\"";
        else if (letra == '\\') resultado += "\\\\";
        else if (letra == '\n') resultado += "\\n";
        else if (letra != '\r') resultado += letra;
    }
    return resultado;
}

string ConvertidorJSON::generartexto() {
    string textofinal = "";
    textofinal += "{\n";
    textofinal += "  \"archivo\": \"resultado_ejecucion\",\n";
    textofinal += "  \"lenguaje\": \"C++\",\n";
    textofinal += "  \"datos_ingresados\": \"" + prepararparajson(datos) + "\",\n";
    textofinal += "  \"lineas_de_salida\": [\n";

    stringstream lector(contenido);
    string linea;
    int contador = 1;
    bool primero = true;

    while(getline(lector, linea, '\n')) {
        if (primero == false) {
            textofinal += ",\n";
        }
        textofinal += "    {\n";
        textofinal += "      \"linea\": " + to_string(contador) + ",\n";
        textofinal += "      \"texto\": \"" + prepararparajson(linea) + "\"\n";
        textofinal += "    }";
        primero = false;
        contador++;
    }

    textofinal += "\n  ]\n}\n";
    return textofinal;
}
