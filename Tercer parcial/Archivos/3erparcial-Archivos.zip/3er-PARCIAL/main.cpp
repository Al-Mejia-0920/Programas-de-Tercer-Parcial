#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "convertidor.h"

using namespace std;

int main() {
    int opcionprincipal = 0;

    while (opcionprincipal != 3) {
        system("cls");

        cout << "1. 1er Parcial" << endl;
        cout << "2. 2do Parcial" << endl;
        cout << "3. Salir" << endl;
        cout << "Elige una opcion: ";
        cin >> opcionprincipal;
        cin.ignore();

        bool procederaconversion = false;
        string contenido = "";
        string datosusados = "Ejecucion completa";


        if (opcionprincipal == 1) {
            system("cls");
            cout << "----------------------------------------" << endl;
            cout << "             1ER PARCIAL                " << endl;
            cout << "----------------------------------------" << endl;
            cout << "Ejercicios: 1, 2, 3, 4, 5, 6, 7, 7.1, 8, 9, 10, 11, 12, 13, 14, 15" << endl;
            cout << "----------------------------------------" << endl;
            cout << "Ingresa el numero del ejercicio que deseas ejecutar : ";
            string opcionejercicio;
            getline(cin, opcionejercicio);

            string nombrearchivo = opcionejercicio + "-ejercicio";

            string carpetaparcial = "1er Parcial";

            string comandocompilar = "g++ \"" + carpetaparcial + "\\" + nombrearchivo + ".cpp\" -o programa_temp.exe";

            if (system(comandocompilar.c_str()) == 0) {
                procederaconversion = true;
            } else {
                cout << "\nError...Escribe el nombre exactamente "
                     << carpetaparcial << "' y contenga el archivo '" << nombrearchivo << ".cpp'." << endl;
            }
        }

        else if (opcionprincipal == 2) {
            system("cls");
            cout << "----------------------------------------" << endl;
            cout << "             2DO PARCIAL                " << endl;
            cout << "----------------------------------------" << endl;
            cout << "Ejercicios :" << endl;
            cout << " pila-arreglo" << endl;
            cout << " cola-puntero" << endl;
            cout << " lista-libreria" << endl;
            cout << "----------------------------------------" << endl;
            cout << "Ingresa el nombre del ejercicio exactamente que deseas ejecutar: ";
            string nombreejercicio;
            getline(cin, nombreejercicio);

            string carpetaparcial2 = "2do Parcial";

            string comandocompilar = "g++ \"" + carpetaparcial2 + "\\" + nombreejercicio + "\"\\*.cpp -o programa_temp.exe";

            if (system(comandocompilar.c_str()) == 0) {
                procederaconversion = true;
            } else {
                cout << "\nError ,Escribe el nombre excatamente " << carpetaparcial2
                     << "\\" << nombreejercicio << "' exista y tenga archivos .cpp adentro." << endl;
            }
        }

        if (procederaconversion) {
            cout << "\n--------------------------------------------" << endl;
            cout << "      PROGRAMA EN EJECUCION                   " << endl;
            cout << "----------------------------------------------\n" << endl;

            system("powershell -Command \"Start-Transcript -Path 'salida_temp.txt' -Force; .\\programa_temp.exe; Stop-Transcript\"");

            ifstream archivo("salida_temp.txt");
            string linea;
            if (archivo.is_open()) {
                int contadorasteriscos = 0;

                while (getline(archivo, linea)) {
                    if (linea.find("**********************") != string::npos) {
                        contadorasteriscos++;
                        continue;
                    }
                    if (contadorasteriscos < 2 || contadorasteriscos >= 3) {
                        continue;
                    }
                    if (linea.find("PS ") != string::npos && linea.find(">") != string::npos) continue;
                    if (linea.find(".\\programa_temp.exe") != string::npos) continue;

                    if (!linea.empty()) {
                        contenido += linea + "\n";
                    }
                }
                archivo.close();
            }

            remove("salida_temp.txt");
            remove("programa_temp.exe");

            cout << "\n-------------------------------------------------" << endl;
            cout << "              SELECCIONA TU FORMATO                " << endl;
            cout << "---------------------------------------------------\n" << endl;
            cout << "1. JSON | 2. XML | 3. CSV | 4. TXT" << endl;
            cout << "Elige una opcion: ";
            int formato;
            cin >> formato;
            cin.ignore();

            cout << "Nombre del nuevo archivo :(sin extension): ";
            string nombre;
            getline(cin, nombre);

            Convertidor* convertidorelegido = nullptr;
            if (formato == 1) convertidorelegido = new ConvertidorJSON(contenido, datosusados);
            else if (formato == 2) convertidorelegido = new ConvertidorXML(contenido, datosusados);
            else if (formato == 3) convertidorelegido = new ConvertidorCSV(contenido, datosusados);
            else if (formato == 4) convertidorelegido = new ConvertidorTXT(contenido, datosusados);

            if (convertidorelegido != nullptr) {
                string ext = (formato == 1) ? ".json" : (formato == 2) ? ".xml" : (formato == 3) ? ".csv" : ".txt";
                convertidorelegido->guardar(nombre + ext);
                cout << "\n�Exito! Archivo " << nombre << ext << " creado." << endl;
                delete convertidorelegido;
            }
            cout << "\nPresiona ENTER para regresar al menu principal...";
            cin.get();
        }
        else if (opcionprincipal == 1 || opcionprincipal == 2) {
            cout << "\nPresiona ENTER para regresar al menu principal...";
            cin.get();
        }
    }
    return 0;
}
