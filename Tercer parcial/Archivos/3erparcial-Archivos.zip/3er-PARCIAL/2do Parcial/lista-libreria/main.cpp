#include <iostream>
#include <string>
#include "concreta.h"

using namespace std;

int main() {
    lista L;
    char opcion;

    while (true) {
        cout << "\n---MENU---\n";
        cout << "1.Agregar\n";
        cout << "2.Quitar\n";
        cout << "3.Mostrar lista\n";
        cout << "4.Esta vacia\n";
        cout << "5.Tamano\n";
        cout << "6.Salir\n";

        cout << "\nOpcion: ";
        cin >> opcion;

        switch (opcion) {
            case '1': {
                string name, eda, pes;
                cout << "Nombre: ";
                cin >> name;
                cout << "Edad: ";
                cin >> eda;
                cout << "Peso: ";
                cin >> pes;

                L.agregar(name, eda, pes);
                break;
            }
            case '2':
                L.quitar();
                break;

            case '3':
                L.mostrar();
                break;

            case '4':
                cout << "Vacia: " << (L.vacia() ? "True" : "False") << "\n";
                break;

            case '5':
                cout << "\nTamano: " << L.tamano() << "\n";
                break;

            case '6':
                cout << "\nAdioooooos\n";
                return 0;

            default:
                cout << "\nERROR\n";
                break;
        }
    }

    return 0;
}
