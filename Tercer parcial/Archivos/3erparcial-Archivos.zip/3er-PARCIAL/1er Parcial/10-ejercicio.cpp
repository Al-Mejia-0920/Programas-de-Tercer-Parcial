#include<iostream>
using namespace std;

int main()
{
    float promedio=0;
    float acumulador=0;
    float suma=0;
    float contenedor[5];
   float* ptr=contenedor;
   float maximo=0;
   float minimo=0;
  for(int i=0;i<5;i++)
  {
      cout<<"Ingrese el numero "<<i+1<<" :";
      cin>>*(ptr+i);
  }

  minimo=*ptr;
  maximo=*ptr;

  for(int x=0;x<5;x++)
  {
      acumulador= *(ptr+x);
      suma=suma + acumulador;
  }
  if(acumulador>maximo)
  {
     maximo=acumulador;
  }
  if(acumulador<minimo)
  {
     minimo=acumulador;
  }

  promedio=suma/5;

cout<<"Suma total : "<<suma<<endl;
cout<<"Promedio o media : "<<promedio<<endl;
cout<<"Maximo : "<<maximo<<endl;
cout<<"Minimo : "<<minimo<<endl;

    return 0;
}

