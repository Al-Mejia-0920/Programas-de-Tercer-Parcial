#include <iostream>

using namespace std;

class Hola {
private:
public:
    void hol() {
        cout << "hola mundo\n";
    }
};

int main() {
    Hola p;
    p.hol();
    return 0;
}
